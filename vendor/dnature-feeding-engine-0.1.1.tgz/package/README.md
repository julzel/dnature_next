# DNAture feeding engine

`@dnature/feeding-engine` is a private npm workspace package. It contains the daily portion formula, four package definitions, calculation rules, generated nutrition catalog, description corrections, and Avify catalog matching. The sales quotation adapter imports this package directly.

From the repository root, run `npm pack --workspace @dnature/feeding-engine --pack-destination /path/to/artifacts`. Install the resulting `.tgz` in the other application's workspace with `npm install /path/to/artifacts/dnature-feeding-engine-0.1.1.tgz`. The tarball contains JavaScript, TypeScript declarations, and the versioned catalog data. To update both apps, update the rules or catalog here, then build and distribute a new package version.

The portion entry point works independently of the catalog. Weight is in kilograms, and the result is in grams per day. The optional second argument selects the existing 14-, 28-, or 30-day rounding convention. The default is 28 days. A `null` result means the formula does not cover the input. The application decides which profiles qualify for a self-service recommendation.

```ts
import { calculateDailyPortion } from "@dnature/feeding-engine/portion";

const portion = calculateDailyPortion({
  species: "dog",
  weight: 8.5,
  lifeStage: "adult",
  neutered: true,
  body: "ideal",
  activity: "calm",
});
// { rawDailyGrams: 212.5, dailyGrams: 220 }
```

For the four standard packages, pass the current Avify response and shared catalog mapping decisions to `createCatalogSnapshot`. Use `builderProfileSchema` to validate the pet input. The application supplies the catalog's availability state and chooses the options it exposes.

```ts
import { buildQuote, builderProfileSchema } from "@dnature/feeding-engine";
import { createCatalogSnapshot } from "@dnature/feeding-engine/catalog";

const catalog = createCatalogSnapshot(avifySnapshot, catalogMappingDecisions);
const profile = builderProfileSchema.parse(petAnswers);
const result = buildQuote({
  pets: [{
    id: profile.id,
    name: profile.name,
    profile,
    selected: {},
    varietyLevel: "medium",
    extras: [],
  }],
  options: { days: 28, complementPercent: 20, firstPurchase: false },
  catalog,
  catalogState: "ready",
});
const packages = result.pets[0]?.result?.packages;
```

Keep Avify credentials and fetches in the calling application's server code. Reuse the same saved mappings and inventory location when both apps should see the same offers. The engine evaluates a supplied snapshot. The package previews expose the existing calculation contract. The customer-specific edit commands are a separate integration step.
